---
description: Ingest a new named roadmap from a local file into .criterion/development/roadmaps/
argument-hint: <name> <file>
---

Ingest a new named roadmap from a local file. Sources:
`.criterion/CODE-OF-CONDUCT.md` §4, template: the highest-versioned
`.criterion/development/roadmaps/templates/TEMPLATE-ROADMAP-vN.md`.
First run `catalyst spec roadmap-add` and follow it: it prints this command's
part of `CODE-OF-CONDUCT.md` §4, the canonical text. Open the sources
above in full only when the spec points elsewhere or a judgment needs
the Rules-of-Rules sections they cite.
Input: $ARGUMENTS

1. Parse `$ARGUMENTS` as `<name> <file>`. If either is missing, ask for it.
2. If `.criterion/development/roadmaps/<name>.md` already exists, refuse and point to
   `/roadmap-update` or `/roadmap-merge` instead.
3. If `.criterion/development/roadmaps/` doesn't exist yet, create it, seed
   `.criterion/development/roadmaps/templates/TEMPLATE-ROADMAP-v1.md` from
   the software-engineering module's `templates/roadmap.template.md`, and
   create an empty `.criterion/development/roadmaps/roadmaps.md` index.
4. Read `<file>` from the local filesystem and identify its distinct
   roadmap items (headings, bullets, table rows — whatever structure the
   source uses).
5. Resolve who is signing this ingest (`CODE-OF-CONDUCT.md` §2); every
   item ingested in the same run shares that signer and its `userid`
   suffix (`Rules-of-Rules.md` §20). `catalyst id next RM --as <signer>`
   gives the first item's ID (it scans every roadmap file, so the sequence
   is global and never reused) and refuses if the signer has no `userid`
   — register one first. Number the remaining items consecutively from it
   in this same write; `id next` does not reserve anything.
6. Create `.criterion/development/roadmaps/<name>.md` from the
   highest-versioned `TEMPLATE-ROADMAP-vN.md` (the one with a
   `Description` column), with `Name: <name>`,
   `Source: <file>`, `Added`/`Last updated` set to today, and one row per
   identified item (`ID`: `RM-NNNNNN-<userid>`; `Description`: a sentence
   or two summarizing the item, drawn from `<file>` — not a restatement
   of `Title`; `Status: Not triaged`, `Linked: *(none)*`,
   `Signed-off-by`: the resolved signer).
7. Register `<name>` in `.criterion/development/roadmaps/roadmaps.md`
   (a hand-edited row — roadmaps have no generated index).
8. Journal it: `catalyst journal append --command /roadmap-add --action create
   --artifact <name> --intent "<goal>" --file <roadmap file> --file <roadmaps.md>`.
9. Report the roadmap name and the IDs assigned. Do not commit or push on your own: the working copy (`.criterion/`)
   and the product repository are committed only with the user's assent.

`catalyst <args>` is `python3 .criterion/bin/catalyst.pyz <args>`
(`CODE-OF-CONDUCT.md` §4).
